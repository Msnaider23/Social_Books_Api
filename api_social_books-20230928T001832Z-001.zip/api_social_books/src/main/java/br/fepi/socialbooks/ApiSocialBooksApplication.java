package br.fepi.socialbooks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiSocialBooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiSocialBooksApplication.class, args);
	}

}
